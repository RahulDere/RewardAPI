package com.retail.rewardapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RewardapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RewardapiApplication.class, args);
	}

}
