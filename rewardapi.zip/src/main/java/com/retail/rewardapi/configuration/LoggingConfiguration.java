package com.retail.rewardapi.configuration;

public class LoggingConfiguration {
}
