package com.retail.rewardapi.configuration;

//@EnableWebSecurity
public class WebSecurityConfiguration {
}
